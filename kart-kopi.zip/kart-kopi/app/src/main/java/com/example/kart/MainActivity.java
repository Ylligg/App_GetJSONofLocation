package com.example.kart;


import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.HttpsURLConnection;
public class MainActivity extends AppCompatActivity{
    private Handler handler;
    private ExecutorService executor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        handler = new Handler();
        executor = Executors.newSingleThreadExecutor();
        Button button = findViewById(R.id.knapp);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makeHttpRequest();
            }
        });
    }

    private void makeHttpRequest() {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    System.out.println("TRY");
                    URL url = new
                            URL("https://maps.googleapis.com/maps/api/geocode/json?address=OSLO"
                            + "&key=AIzaSyDVwoXDcJUx6j9ipTDgh_sBQsFbYsMqEBk");
                    HttpURLConnection httpUrlConnection = (HttpURLConnection) url.openConnection();
                    httpUrlConnection.setRequestMethod("GET");
                    httpUrlConnection.connect();
                    int responseCode = httpUrlConnection.getResponseCode();
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        InputStream inputStream = httpUrlConnection.getInputStream();
                        String response = readInputStreamToString(inputStream);
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                TextView textView = findViewById(R.id.textView);
                                textView.setText(response);
                            }
                        });
                    }

                    else { handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "Error: " + responseCode,
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                    }
                } catch (Exception e) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "Error: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

    private String readInputStreamToString(InputStream inputStream)
            throws IOException {
        BufferedReader reader = new BufferedReader(new
                InputStreamReader(inputStream));
        StringBuilder stringBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            stringBuilder.append(line);
        }
        reader.close();
        return stringBuilder.toString();
    }
}